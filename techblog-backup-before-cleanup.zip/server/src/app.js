/**
 * @file app.js
 * @description Express application factory.
 *
 * RESPONSIBILITY:
 *   This file owns the Express *application* (middleware + routes).
 *   The HTTP *server* is created separately in index.js.
 *   Keeping them separate makes the app easier to test (you can import
 *   app without actually binding to a port).
 *
 * MIDDLEWARE STACK (in order):
 *   1. helmet       — sets secure HTTP headers
 *   2. cors         — allows the React client to call this API
 *   3. morgan       — HTTP request logging
 *   4. express.json — parses JSON request bodies
 *   5. mongoSanitize— strips MongoDB operators from user input (NoSQL injection)
 *   6. rateLimiter  — limits repeated requests from one IP (brute-force guard)
 *   7. routes       — all API route groups
 *   8. 404 handler  — catches any unmatched route
 *   9. errorHandler — global error handler (must be last)
 */

import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import mongoSanitize from 'express-mongo-sanitize';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import mongoose from 'mongoose';

import env from './config/env.js';
import errorHandler from './middleware/errorHandler.js';
import { sendError } from './utils/apiResponse.js';

// ── Route imports ────────────────────────────────────────────────────────────
import authRoutes from './routes/authRoutes.js';
import postRoutes from './routes/postRoutes.js';
import categoryRoutes from './routes/categoryRoutes.js';
import uploadRoutes from './routes/uploadRoutes.js';
import seoRoutes from './routes/seoRoutes.js';
import newsletterRoutes from './routes/newsletterRoutes.js';

// ── ESM-compatible __dirname ──────────────────────────────────────────────────
// Node's ESM modules don't expose __dirname, so we derive it from import.meta.
const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// ── Create the Express app ────────────────────────────────────────────────────
const app = express();

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 1. SECURITY HEADERS — helmet sets ~15 HTTP headers that harden the API
//    against common attacks (clickjacking, MIME sniffing, XSS, etc.)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app.use(helmet());

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 2. CORS — Cross-Origin Resource Sharing
//    Allows the React client (running on a different port) to call this API.
//    In production CLIENT_URL should be your real domain.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const corsOptions = {
  // Allow requests from the React dev server and the production frontend
  origin: (origin, callback) => {
    const allowed = [env.CLIENT_URL, 'http://localhost:3000', 'http://localhost:5173'];

    // Allow requests with no origin (Postman, curl, server-to-server)
    if (!origin || allowed.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS: origin "${origin}" not allowed`));
    }
  },
  credentials: true,                    // Allow cookies / Authorization header
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
};

app.use(cors(corsOptions));

// Explicitly handle preflight (OPTIONS) requests for all routes.
// Browsers send a preflight before any cross-origin request with a custom header.
app.options('*', cors(corsOptions));

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 3. HTTP REQUEST LOGGING — morgan
//    'dev' format: "GET /api/posts 200 12ms"
//    Skip in test environment to keep test output clean.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if (env.NODE_ENV !== 'test') {
  app.use(morgan(env.IS_DEV ? 'dev' : 'combined'));
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 4. BODY PARSERS
//    express.json()       — parse application/json bodies (limit 10 MB for
//                           posts with embedded base64 images during drafting)
//    express.urlencoded() — parse HTML form submissions
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 5. NoSQL INJECTION SANITIZATION — express-mongo-sanitize
//    Strips keys that start with '$' or contain '.' from req.body, req.query,
//    and req.params, preventing MongoDB operator injection attacks.
//    Example attack: { "email": { "$gt": "" } } → stripped to {}
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app.use(mongoSanitize());

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 6. RATE LIMITING — express-rate-limit
//    Prevents brute-force and denial-of-service attacks.
//    Default: 100 requests per 15-minute window per IP address.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const limiter = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS, // 15 minutes
  max: env.RATE_LIMIT_MAX,            // max requests per window per IP
  standardHeaders: true,              // Return rate limit info in `RateLimit-*` headers
  legacyHeaders: false,               // Disable the deprecated `X-RateLimit-*` headers
  message: {
    success: false,
    message: 'Too many requests from this IP. Please try again after 15 minutes.',
  },
});

// Apply the rate limiter to ALL API routes.
// If you need a stricter limiter on login specifically, we'll add that in Step 4.
app.use('/api', limiter);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 7. STATIC FILES — serve uploaded images in development
//    In production, images are served from Cloudinary CDN instead.
//    URL: http://localhost:5000/uploads/images/my-photo.jpg
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app.use(
  '/uploads',
  express.static(path.join(__dirname, '..', 'uploads'))
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 8. HEALTH CHECK & ROOT STATUS — verifies server & database connection state.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app.get('/', (_req, res) => {
  const isConnected = mongoose.connection.readyState === 1;
  const dbStatus = isConnected ? 'Connected' : 'Disconnected';
  res.status(200).send(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>TechBlog API Server</title>
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; background: #0f172a; color: #f8fafc; }
        .card { background: #1e293b; border-radius: 16px; padding: 36px 48px; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.4); max-width: 520px; width: 100%; text-align: center; border: 1px solid #334155; }
        h1 { margin: 0 0 12px; font-size: 26px; }
        .badge { display: inline-flex; align-items: center; gap: 8px; padding: 6px 16px; border-radius: 9999px; font-weight: 600; font-size: 14px; margin: 16px 0; background: #064e3b; color: #34d399; border: 1px solid #059669; }
        .badge.disconnected { background: #7f1d1d; color: #f87171; border-color: #dc2626; }
        .dot { width: 10px; height: 10px; border-radius: 50%; background: #10b981; }
        .badge.disconnected .dot { background: #ef4444; }
        p { color: #94a3b8; line-height: 1.6; margin: 8px 0; font-size: 15px; }
        .links { margin-top: 24px; display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
        a { color: #38bdf8; text-decoration: none; font-weight: 500; font-size: 14px; padding: 8px 16px; background: #0f172a; border-radius: 8px; border: 1px solid #334155; transition: all 0.2s; }
        a:hover { background: #38bdf8; color: #0f172a; }
      </style>
    </head>
    <body>
      <div class="card">
        <h1>🚀 TechBlog API Server</h1>
        <div class="badge ${isConnected ? '' : 'disconnected'}">
          <span class="dot"></span>
          MongoDB Atlas: ${dbStatus}
        </div>
        <p><strong>Database:</strong> ${mongoose.connection.name || 'techblog'}</p>
        <p><strong>Host:</strong> ${mongoose.connection.host || 'MongoDB Atlas'}</p>
        <div class="links">
          <a href="/api/health" target="_blank">Health Check</a>
          <a href="/api/posts" target="_blank">Posts API</a>
          <a href="/api/categories" target="_blank">Categories API</a>
          <a href="http://localhost:3000" target="_blank">Open Frontend (Port 3000)</a>
        </div>
      </div>
    </body>
    </html>
  `);
});

app.get('/api/health', (_req, res) => {
  const dbState = ['disconnected', 'connected', 'connecting', 'disconnecting'][mongoose.connection.readyState] || 'unknown';
  res.status(200).json({
    success: true,
    message: 'TechBlog API is running 🚀',
    database: {
      status: dbState,
      connected: mongoose.connection.readyState === 1,
      host: mongoose.connection.host || null,
      name: mongoose.connection.name || null,
    },
    environment: env.NODE_ENV,
    timestamp: new Date().toISOString(),
  });
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 9. API ROUTES
//    Each route group is mounted at a versioned prefix (/api/...).
//    Uncommenting these stubs in later steps is all that's needed.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app.use('/api/auth', authRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/newsletter', newsletterRoutes);
app.use('/', seoRoutes);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 10. 404 — catch any request that didn't match a route above
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app.use((req, res) => {
  sendError(res, `Route not found: ${req.method} ${req.originalUrl}`, 404);
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 11. GLOBAL ERROR HANDLER — MUST be the very last app.use() call.
//     Express identifies error handlers by their (err, req, res, next) signature.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
app.use(errorHandler);

export default app;
