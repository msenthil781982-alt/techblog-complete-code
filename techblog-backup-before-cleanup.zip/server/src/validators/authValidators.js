/**
 * @file validators/authValidators.js
 * @description express-validator rule chains for authentication routes.
 *
 * HOW VALIDATORS WORK IN THIS PROJECT:
 *   Each export is an array of express-validator `body()` checks.
 *   They're placed BETWEEN the route definition and the controller:
 *
 *     router.post('/login', loginRules, validate, authController.login)
 *                            ^^^^^^^^   ^^^^^^^^
 *                            rules      checker middleware (middleware/validate.js)
 *
 *   If ANY rule fails, `validate` sends a 400 response with field-level
 *   errors and the controller never runs.
 */

import { body } from 'express-validator';

/**
 * loginRules — validation for POST /api/auth/login
 */
export const loginRules = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Please provide a valid email address')
    .normalizeEmail(), // lowercase, remove dots in gmail addresses

  body('password')
    .notEmpty().withMessage('Password is required')
    .isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
];

/**
 * registerRules — validation for POST /api/auth/register
 */
export const registerRules = [
  body('name')
    .trim()
    .notEmpty().withMessage('Name is required')
    .isLength({ min: 2, max: 100 }).withMessage('Name must be between 2 and 100 characters'),

  body('email')
    .trim()
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Please provide a valid email address')
    .normalizeEmail(),

  body('password')
    .notEmpty().withMessage('Password is required')
    .isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
];

/**
 * refreshRules — validation for POST /api/auth/refresh
 */
export const refreshRules = [
  body('refreshToken')
    .notEmpty().withMessage('Refresh token is required')
    .isString().withMessage('Refresh token must be a string'),
];
