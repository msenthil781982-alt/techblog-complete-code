/**
 * @file config/env.js
 * @description Centralised environment variable access with validation.
 *
 * WHY this file exists:
 *   Reading process.env directly throughout the codebase is fragile —
 *   a missing variable crashes the server at runtime in an unexpected place.
 *   Here we validate everything at startup and export a frozen config object
 *   so the rest of the app imports clean, typed values.
 *
 * USAGE:
 *   import env from './config/env.js';
 *   console.log(env.PORT);        // 5000
 *   console.log(env.MONGO_URI);   // mongodb://...
 */

import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load server/.env based on file location regardless of current working directory
dotenv.config({ path: path.resolve(__dirname, '../../.env') });
// Also check workspace root .env if present
dotenv.config({ path: path.resolve(__dirname, '../../../.env') });
// Fall back to cwd .env
dotenv.config();

/**
 * validateEnv — checks that every required variable exists.
 * Throws an Error listing ALL missing variables at once so the developer
 * doesn't have to restart multiple times to find them all.
 */
function validateEnv() {
  const mongoUri = process.env.MONGO_URI || process.env.MONGO_URL;
  const required = [
    'JWT_SECRET',
    'JWT_REFRESH_SECRET',
  ];

  const missing = required.filter((key) => !process.env[key]);
  if (!mongoUri) {
    missing.unshift('MONGO_URI (or MONGO_URL)');
  }

  if (missing.length > 0) {
    throw new Error(
      `[env] Missing required environment variables:\n  ${missing.join('\n  ')}\n` +
      `  → Copy .env.example to .env and fill in the values.`
    );
  }
}

// Run validation immediately when this module is imported.
validateEnv();

/**
 * env — the single source of truth for configuration.
 * Object.freeze() prevents accidental mutation from anywhere in the app.
 */
const env = Object.freeze({
  // --- Server ---
  PORT: parseInt(process.env.PORT, 10) || 5000,
  NODE_ENV: process.env.NODE_ENV || 'development',

  // --- MongoDB ---
  MONGO_URI: process.env.MONGO_URI || process.env.MONGO_URL,

  // --- JWT ---
  JWT_SECRET: process.env.JWT_SECRET,
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET,
  JWT_REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN || '30d',

  // --- Admin seeder ---
  ADMIN_EMAIL: process.env.ADMIN_EMAIL || 'admin@techblog.com',
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || 'Admin@123456',

  // --- CORS ---
  CLIENT_URL: process.env.CLIENT_URL || 'http://localhost:3000',

  // --- Cloudinary (optional — only required when NODE_ENV === 'production') ---
  CLOUDINARY_CLOUD_NAME: process.env.CLOUDINARY_CLOUD_NAME || '',
  CLOUDINARY_API_KEY: process.env.CLOUDINARY_API_KEY || '',
  CLOUDINARY_API_SECRET: process.env.CLOUDINARY_API_SECRET || '',

  // --- Resend Email Service ---
  RESEND_API_KEY: process.env.RESEND_API_KEY || '',
  EMAIL_FROM: process.env.EMAIL_FROM || 'TechBlog <onboarding@resend.dev>',

  // --- Rate limiting ---
  RATE_LIMIT_WINDOW_MS: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 900_000, // 15 min
  RATE_LIMIT_MAX: parseInt(process.env.RATE_LIMIT_MAX, 10) || 100,

  // --- Derived helpers ---
  IS_DEV: (process.env.NODE_ENV || 'development') === 'development',
  IS_PROD: process.env.NODE_ENV === 'production',
});

export default env;
