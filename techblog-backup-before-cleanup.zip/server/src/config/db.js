/**
 * @file config/db.js
 * @description MongoDB connection via Mongoose.
 *
 * HOW IT WORKS:
 *   mongoose.connect() returns a Promise.
 *   We export an async function `connectDB` called once from index.js.
 *   Mongoose keeps an internal connection pool — no need to pass the
 *   connection object around; models just work after connectDB() resolves.
 *
 * EVENTS:
 *   Mongoose emits 'connected', 'error', and 'disconnected' events on
 *   the default connection. We log them for observability.
 *
 * USAGE:
 *   import connectDB from './config/db.js';
 *   await connectDB();
 */

import mongoose from 'mongoose';
import env from './env.js';
import logger from '../utils/logger.js';

/**
 * connectDB — establishes the MongoDB connection.
 * @returns {Promise<void>}
 */
const connectDB = async () => {
  try {
    // 15 seconds timeout provides enough headroom for DNS lookup & TLS handshake with Atlas
    const conn = await mongoose.connect(env.MONGO_URI, {
      serverSelectionTimeoutMS: 15000,
    });

    logger.info(`MongoDB connected → ${conn.connection.host}`);
  } catch (error) {
    logger.error(`MongoDB connection failed: ${error.message}`);
    // Exit process — the server cannot function without a database.
    process.exit(1);
  }
};

// ── Mongoose connection lifecycle events ──────────────────────────────────────

mongoose.connection.on('disconnected', () => {
  logger.warn('MongoDB disconnected. Attempting to reconnect…');
});

mongoose.connection.on('reconnected', () => {
  logger.info('MongoDB reconnected.');
});

// In development, log every Mongoose query for debugging.
if (env.IS_DEV) {
  mongoose.set('debug', (collectionName, methodName, ...methodArgs) => {
    logger.debug(`Mongoose → ${collectionName}.${methodName}(${JSON.stringify(methodArgs[0])})`);
  });
}

export default connectDB;
