/**
 * @file models/Post.js
 * @description Mongoose schema & model for Blog Posts — the core data entity.
 *
 * ════════════════════════════════════════════════════════════════════════════
 * FIELD GROUPS:
 *
 *  Content:      title, slug, content (HTML), excerpt, featuredImage
 *  Taxonomy:     category (→ Category), tags ([→ Tag])
 *  Authorship:   author (→ User)
 *  Publishing:   status, scheduledAt, publishedAt
 *  SEO:          seo sub-document { metaTitle, metaDescription, ogImage, canonicalUrl }
 *  Engagement:   views, readingTime, isFeatured
 * ════════════════════════════════════════════════════════════════════════════
 *
 * STATUS LIFECYCLE:
 *   draft → published   (immediate publish)
 *   draft → scheduled   (auto-publish at scheduledAt via node-cron in Step 8)
 *   scheduled → published (cron job fires)
 *   published → draft   (unpublish / take offline)
 *
 * KEY DESIGN DECISIONS:
 *   - `slug` is unique; generated from title if not provided.
 *   - `content` stores the HTML output of the rich-text editor (TipTap/Quill).
 *   - `readingTime` is auto-calculated on save via the readingTime util.
 *   - `excerpt` is auto-generated from content if left blank (first 160 chars).
 *   - SEO fields fall back to title/excerpt if not explicitly filled in.
 *   - `views` is updated by an atomic $inc in the controller (not in this model)
 *     to avoid triggering the full save pipeline on every page view.
 *
 * USAGE:
 *   import Post from '../models/Post.js';
 *   const posts = await Post.find({ status: 'published' })
 *     .populate('author', 'name avatar')
 *     .populate('category', 'name slug color')
 *     .sort({ publishedAt: -1 });
 */

import mongoose from 'mongoose';
import { ensureUniqueSlug } from '../utils/slugHelper.js';
import calculateReadingTime from '../utils/readingTime.js';

const { Schema, model } = mongoose;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SUB-SCHEMA: Featured Image
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const featuredImageSchema = new Schema(
  {
    url: { type: String, default: '' },      // Public URL (local path or Cloudinary)
    altText: { type: String, default: '' },  // For accessibility & SEO
    caption: { type: String, default: '' },  // Optional caption shown below image
  },
  { _id: false } // No separate _id for sub-documents
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SUB-SCHEMA: SEO Fields
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const seoSchema = new Schema(
  {
    // The <title> tag in <head> — ideally 50-60 chars.
    // Falls back to post.title if empty.
    metaTitle: {
      type: String,
      trim: true,
      maxlength: [70, 'Meta title should be 70 characters or less'],
      default: '',
    },

    // The <meta name="description"> — ideally 150-160 chars.
    // Falls back to post.excerpt if empty.
    metaDescription: {
      type: String,
      trim: true,
      maxlength: [170, 'Meta description should be 170 characters or less'],
      default: '',
    },

    // Open Graph image URL — shown when shared on social media.
    // Falls back to post.featuredImage.url if empty.
    ogImage: {
      type: String,
      default: '',
    },

    // Canonical URL — prevents duplicate content penalties when the same
    // article is accessible at multiple URLs.
    canonicalUrl: {
      type: String,
      default: '',
    },
  },
  { _id: false }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MAIN SCHEMA: Post
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const postSchema = new Schema(
  {
    // ── Content ───────────────────────────────────────────────────────────────
    title: {
      type: String,
      required: [true, 'Post title is required'],
      trim: true,
      maxlength: [200, 'Title must be 200 characters or less'],
    },

    slug: {
      type: String,
      unique: true,
      lowercase: true,
      trim: true,
      // Auto-generated in pre-save hook if not provided
    },

    // Full article body — HTML string from TipTap/Quill rich-text editor.
    // We store HTML rather than Markdown so the frontend can render it
    // directly without a parse step.
    content: {
      type: String,
      required: [true, 'Post content is required'],
    },

    // Short summary (plain text, no HTML) used in listing cards and meta description.
    // Auto-generated from content if left blank.
    excerpt: {
      type: String,
      trim: true,
      maxlength: [300, 'Excerpt must be 300 characters or less'],
      default: '',
    },

    featuredImage: {
      type: featuredImageSchema,
      default: () => ({}),
    },

    // ── Taxonomy ──────────────────────────────────────────────────────────────

    // Every post belongs to exactly one category.
    category: {
      type: Schema.Types.ObjectId,
      ref: 'Category',
      required: [true, 'Category is required'],
    },

    // A post can have zero to many tags.
    tags: [
      {
        type: Schema.Types.ObjectId,
        ref: 'Tag',
      },
    ],

    // ── Authorship ────────────────────────────────────────────────────────────
    author: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Author is required'],
    },

    // ── Publishing ────────────────────────────────────────────────────────────

    /**
     * status values:
     *   "pending"   — submitted by user, waiting for admin approval
     *   "approved"  — approved by admin and published live
     *   "rejected"  — rejected by admin, not visible publicly
     *   "published" — live and visible immediately (legacy/admin)
     *   "draft"     — saved draft
     *   "scheduled" — will be auto-published at scheduledAt
     */
    status: {
      type: String,
      enum: {
        values: ['pending', 'approved', 'rejected', 'draft', 'published', 'scheduled'],
        message: 'Status must be pending, approved, rejected, draft, published, or scheduled',
      },
      default: 'pending',
    },

    // The date/time this post was (or will be) published.
    // Set automatically when status changes to 'published'.
    // Set manually when status is 'scheduled'.
    publishedAt: {
      type: Date,
      default: null,
    },

    // Target publish date/time for scheduled posts (future date required).
    scheduledAt: {
      type: Date,
      default: null,
      validate: {
        validator: function (val) {
          // Only validate if status is 'scheduled'
          if (this.status !== 'scheduled') return true;
          return val && val > new Date(); // must be a future date
        },
        message: 'Scheduled date must be a future date/time',
      },
    },

    // ── Computed / Derived ────────────────────────────────────────────────────

    // Estimated reading time in minutes — auto-calculated in pre-save hook.
    readingTime: {
      type: Number,
      default: 1,
      min: 1,
    },

    // ── Engagement ────────────────────────────────────────────────────────────

    // Page view counter — incremented atomically via $inc in the controller.
    // We DON'T update this in the model's save hook to avoid triggering
    // all the pre-save middleware on every page view.
    views: {
      type: Number,
      default: 0,
      min: 0,
    },

    // Whether this post is pinned to the Featured section on the homepage.
    // Only a small number of posts should have this set to true at once.
    isFeatured: {
      type: Boolean,
      default: false,
    },

    // ── SEO ───────────────────────────────────────────────────────────────────
    seo: {
      type: seoSchema,
      default: () => ({}),
    },
  },
  {
    timestamps: true, // createdAt, updatedAt
    toJSON: {
      virtuals: true,
      transform: (_doc, ret) => {
        ret.id = ret._id;
        delete ret._id;
        delete ret.__v;
        return ret;
      },
    },
    toObject: { virtuals: true },
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PRE-SAVE MIDDLEWARE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

postSchema.pre('save', async function (next) {
  // ── 1. Slug generation ──────────────────────────────────────────────────
  // Auto-generate slug from title on creation.
  // On edit: only regenerate if the title changed AND no custom slug set.
  if (!this.slug || (this.isModified('title') && this.isNew)) {
    // ensureUniqueSlug checks the DB and appends -2, -3 if needed.
    this.slug = await ensureUniqueSlug(this.title, this.constructor, this._id);
  } else if (this.isModified('slug')) {
    // If slug was manually edited, still guarantee uniqueness.
    this.slug = await ensureUniqueSlug(this.slug, this.constructor, this._id);
  }

  // ── 2. Auto-generate excerpt from content ───────────────────────────────
  if (!this.excerpt && this.content) {
    // Strip HTML tags and take the first 160 characters of plain text.
    const plainText = this.content
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    this.excerpt = plainText.substring(0, 160).trim();
    // Add ellipsis if we cut the text short
    if (plainText.length > 160) this.excerpt += '…';
  }

  // ── 3. Calculate reading time ───────────────────────────────────────────
  if (this.isModified('content')) {
    this.readingTime = calculateReadingTime(this.content);
  }

  // ── 4. Set publishedAt when status changes to 'published' or 'approved' ───
  if (this.isModified('status') && (this.status === 'published' || this.status === 'approved') && !this.publishedAt) {
    this.publishedAt = new Date();
  }

  // ── 5. Clear scheduledAt when moving out of 'scheduled' ────────────────
  if (this.isModified('status') && this.status !== 'scheduled') {
    this.scheduledAt = null;
  }

  // ── 6. SEO field fallbacks ──────────────────────────────────────────────
  // If the author didn't fill in SEO fields, default to the post's own content.
  if (!this.seo.metaTitle) {
    this.seo.metaTitle = this.title.substring(0, 70);
  }
  if (!this.seo.metaDescription) {
    this.seo.metaDescription = this.excerpt.substring(0, 160);
  }
  if (!this.seo.ogImage && this.featuredImage?.url) {
    this.seo.ogImage = this.featuredImage.url;
  }

  next();
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VIRTUALS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * post.url — the canonical public URL for this post.
 * "/blog/my-post-slug"
 * Used in sitemaps, Open Graph tags, and related-post links.
 */
postSchema.virtual('url').get(function () {
  return `/blog/${this.slug}`;
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// INDEXES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Primary public query: published posts sorted by date (homepage, listing page)
postSchema.index({ status: 1, publishedAt: -1 });

// Category page query: posts in a category, latest first
postSchema.index({ category: 1, status: 1, publishedAt: -1 });

// Tag page query: posts with a specific tag
postSchema.index({ tags: 1, status: 1 });

// Author admin query: all posts by a specific author
postSchema.index({ author: 1, status: 1 });

// Featured posts on homepage (only a few)
postSchema.index({ isFeatured: 1, status: 1 });

// Full-text search across title and excerpt
postSchema.index({ title: 'text', excerpt: 'text', content: 'text' });

// Slug is the primary GET /:slug lookup
// (unique: true in the field definition already creates an index)

// Scheduled posts — the cron job queries for status=scheduled, scheduledAt <= now
postSchema.index({ status: 1, scheduledAt: 1 });

// Duplicate prevention: same author cannot create two posts with the same title.
// The controller checks this explicitly (409 response), and this index backs it up.
// NOTE: This is NOT a unique index (to allow admins to still create same-title posts
// for different categories), but it speeds up the duplicate check query.
postSchema.index({ author: 1, title: 1 });

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// STATIC METHODS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Post.incrementViews(slug)
 * Atomically increments the view counter for a post by slug.
 * We use $inc directly (not .save()) so the pre-save hooks don't run —
 * this keeps view tracking lightweight and fast.
 *
 * @param {string} slug - Post slug
 * @returns {Promise<Document>}
 */
postSchema.statics.incrementViews = function (slug) {
  return this.findOneAndUpdate(
    { slug, status: { $in: ['approved', 'published'] } },
    { $inc: { views: 1 } },
    { new: true }
  );
};

/**
 * Post.getRelated(post, limit)
 * Finds posts in the same category (excluding the current post).
 * Falls back to trending posts if the category has fewer than `limit` posts.
 *
 * @param {Document} post  - The current post document
 * @param {number}   limit - Max number of related posts to return (default 3)
 * @returns {Promise<Document[]>}
 */
postSchema.statics.getRelated = function (post, limit = 3) {
  return this.find({
    _id: { $ne: post._id },            // exclude current post
    status: { $in: ['approved', 'published'] },
    category: post.category,            // same category
  })
    .select('title slug excerpt featuredImage readingTime publishedAt category')
    .populate('category', 'name slug color')
    .sort({ publishedAt: -1 })
    .limit(limit)
    .lean();
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// EXPORT
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const Post = model('Post', postSchema);
export default Post;
