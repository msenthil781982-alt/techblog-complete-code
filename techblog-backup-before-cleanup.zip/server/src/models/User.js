/**
 * @file models/User.js
 * @description Mongoose schema & model for Admin / Author users.
 *
 * ROLES:
 *   "admin"  — full access: create/edit/delete any post, manage categories,
 *              manage other authors.
 *   "author" — can create and edit their OWN posts; cannot delete others'.
 *
 * FIELDS:
 *   name        - Display name shown on article author cards
 *   email       - Unique login identifier
 *   password    - bcrypt-hashed; NEVER returned in API responses (select: false)
 *   role        - "admin" | "author"
 *   avatar      - Profile image URL
 *   bio         - Short author biography displayed on the blog
 *   social      - Object holding optional social profile URLs
 *   isActive    - Soft-disable an author without deleting their posts
 *   lastLoginAt - Tracked for security audit purposes
 *
 * SECURITY NOTES:
 *   - `password` field has `select: false` — excluded from ALL queries by default.
 *     To include it (login): User.findOne({ email }).select('+password')
 *   - Passwords are hashed with bcrypt (salt rounds = 12) in a pre-save hook.
 *   - comparePassword() is an instance method — never expose the hash.
 *
 * USAGE:
 *   import User from '../models/User.js';
 *   const admin = await User.findOne({ email }).select('+password');
 *   const match = await admin.comparePassword('plaintext');
 */

import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const { Schema, model } = mongoose;

// ── Schema Definition ─────────────────────────────────────────────────────────
const userSchema = new Schema(
  {
    // ── Identity ──────────────────────────────────────────────────────────────
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      maxlength: [100, 'Name must be 100 characters or less'],
    },

    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      trim: true,
      lowercase: true,
      match: [
        /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,})+$/,
        'Please provide a valid email address',
      ],
    },

    // ── Authentication ────────────────────────────────────────────────────────
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: [8, 'Password must be at least 8 characters'],
      // select: false means this field is EXCLUDED from query results by default.
      // It must be explicitly requested: User.findOne({...}).select('+password')
      select: false,
    },

    // ── Authorisation ─────────────────────────────────────────────────────────
    role: {
      type: String,
      enum: {
        values: ['admin', 'author', 'user'],
        message: 'Role must be "admin", "author", or "user"',
      },
      default: 'user',
    },

    // ── Profile ───────────────────────────────────────────────────────────────
    avatar: {
      type: String,
      default: '', // empty string = show initials avatar in the UI
    },

    bio: {
      type: String,
      trim: true,
      maxlength: [500, 'Bio must be 500 characters or less'],
      default: '',
    },

    // Social links — all optional, stored as a sub-document object
    social: {
      twitter:  { type: String, default: '' },
      linkedin: { type: String, default: '' },
      github:   { type: String, default: '' },
      website:  { type: String, default: '' },
    },

    // ── Admin controls ────────────────────────────────────────────────────────
    isActive: {
      type: Boolean,
      default: true,
    },

    lastLoginAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true, // adds createdAt, updatedAt
    toJSON: {
      virtuals: true,
      transform: (_doc, ret) => {
        ret.id = ret._id;
        delete ret._id;
        delete ret.__v;
        delete ret.password; // extra safety — never leak password hash
        return ret;
      },
    },
    toObject: { virtuals: true },
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MIDDLEWARE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Hash password before saving.
 *
 * WHY pre-save and not in the controller?
 *   Keeping hashing in the model means it happens automatically for
 *   ALL code paths — the seed script, the controller, future imports.
 *   You can never accidentally save a plain-text password.
 *
 * Salt rounds = 12:
 *   10 is the express default; 12 adds ~4× more computation cost for
 *   attackers while remaining fast enough for a login endpoint.
 */
userSchema.pre('save', async function (next) {
  // Only hash if the password field was actually changed.
  // Without this guard, every other field update (e.g. changing bio)
  // would re-hash the already-hashed password, breaking login.
  if (!this.isModified('password')) return next();

  const SALT_ROUNDS = 12;
  this.password = await bcrypt.hash(this.password, SALT_ROUNDS);
  next();
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// INSTANCE METHODS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * user.comparePassword(candidatePassword)
 * Compares a plain-text password against the stored bcrypt hash.
 *
 * bcrypt.compare() is timing-safe — it doesn't short-circuit on
 * the first character mismatch, preventing timing attacks.
 *
 * @param  {string}  candidatePassword - The password submitted via login form
 * @returns {Promise<boolean>}         - true if correct, false if wrong
 */
userSchema.methods.comparePassword = async function (candidatePassword) {
  // `this.password` is available because the controller selected it explicitly.
  return bcrypt.compare(candidatePassword, this.password);
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VIRTUALS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * user.initials — computed from name, used for the avatar fallback.
 * "John Doe" → "JD"
 */
userSchema.virtual('initials').get(function () {
  return this.name
    .split(' ')
    .map((word) => word[0]?.toUpperCase() ?? '')
    .slice(0, 2)
    .join('');
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// INDEXES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// email is the primary lookup field (login); unique: true creates the index.
// role index helps when filtering the author management list by role.
userSchema.index({ role: 1 });

const User = model('User', userSchema);
export default User;
