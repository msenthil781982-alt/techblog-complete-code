/**
 * @file models/Category.js
 * @description Mongoose schema & model for Blog Categories.
 *
 * FIELDS:
 *   name        - Display name, e.g. "Artificial Intelligence & Machine Learning"
 *   slug        - URL segment, e.g. "artificial-intelligence-machine-learning"
 *   description - Short summary shown on category listing pages
 *   icon        - React-icons name or emoji shown next to the category name
 *   color       - Tailwind color name used for the category badge (e.g. "blue")
 *   postCount   - Denormalised counter updated when posts are published/deleted.
 *                 Avoids a COUNT query on the posts collection every page load.
 *   isActive    - Soft-toggle to hide a category without deleting it
 *
 * NOTES:
 *   - `slug` has a unique index — no two categories can share a URL.
 *   - Timestamps (createdAt, updatedAt) are added automatically by Mongoose.
 *
 * USAGE:
 *   import Category from '../models/Category.js';
 *   const cats = await Category.find({ isActive: true }).sort('name');
 */

import mongoose from 'mongoose';
import { generateSlug } from '../utils/slugHelper.js';

const { Schema, model } = mongoose;

// ── Schema Definition ─────────────────────────────────────────────────────────
const categorySchema = new Schema(
  {
    // ── Identity ──────────────────────────────────────────────────────────────
    name: {
      type: String,
      required: [true, 'Category name is required'],
      trim: true,
      unique: true,
      maxlength: [100, 'Category name must be 100 characters or less'],
    },

    slug: {
      type: String,
      unique: true,
      lowercase: true,
      trim: true,
      // Slug is auto-generated in the pre-save hook below if not provided.
      // It can also be provided explicitly (e.g. from the admin form).
    },

    // ── Display ───────────────────────────────────────────────────────────────
    description: {
      type: String,
      trim: true,
      maxlength: [500, 'Description must be 500 characters or less'],
      default: '',
    },

    // Icon identifier — we store a string like "FiCpu" (react-icons name)
    // or a simple emoji like "🤖". The frontend decides how to render it.
    icon: {
      type: String,
      default: '📁',
    },

    // Tailwind color key: "blue" | "green" | "purple" | "red" | "orange" | etc.
    // The frontend maps this to Tailwind classes like bg-blue-100 text-blue-700.
    color: {
      type: String,
      default: 'blue',
      enum: {
        values: ['blue', 'green', 'purple', 'red', 'orange', 'cyan', 'pink', 'yellow', 'indigo', 'gray'],
        message: '{VALUE} is not a valid color',
      },
    },

    // ── Stats (denormalised) ──────────────────────────────────────────────────
    postCount: {
      type: Number,
      default: 0,
      min: 0,
    },

    // ── Admin controls ────────────────────────────────────────────────────────
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    // Automatically adds `createdAt` and `updatedAt` fields
    timestamps: true,

    // When converting to JSON (e.g. res.json()), remove MongoDB internals
    // and rename `_id` to `id` for cleaner API responses.
    toJSON: {
      virtuals: true,
      transform: (_doc, ret) => {
        ret.id = ret._id;
        delete ret._id;
        delete ret.__v;
        return ret;
      },
    },
    toObject: { virtuals: true },
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MIDDLEWARE (pre-save hooks)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Auto-generate slug from name before saving.
 * Only runs if the name was modified (new doc or name changed).
 * If a slug was manually provided, we still normalise it through generateSlug.
 */
categorySchema.pre('save', function (next) {
  // `this` refers to the document being saved
  if (this.isModified('name') || !this.slug) {
    this.slug = this.slug
      ? generateSlug(this.slug)   // normalise an explicitly provided slug
      : generateSlug(this.name);  // auto-generate from name
  }
  next();
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// INDEXES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// slug is the primary lookup field (GET /api/categories/:slug)
// The unique: true in the field definition already creates an index,
// but we add an explicit text index on `name` for search purposes.
categorySchema.index({ name: 'text' });

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// STATIC METHODS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Category.incrementPostCount(categoryId)
 * Atomically increments the denormalised postCount by 1.
 * Called by the Post model's post-save hook when a post is published.
 */
categorySchema.statics.incrementPostCount = function (categoryId) {
  return this.findByIdAndUpdate(categoryId, { $inc: { postCount: 1 } });
};

/**
 * Category.decrementPostCount(categoryId)
 * Atomically decrements postCount by 1 (minimum 0).
 * Called when a published post is deleted or moved to draft.
 */
categorySchema.statics.decrementPostCount = function (categoryId) {
  return this.findByIdAndUpdate(categoryId, { $inc: { postCount: -1 } });
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// EXPORT
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const Category = model('Category', categorySchema);
export default Category;
