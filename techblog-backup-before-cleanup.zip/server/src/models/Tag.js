/**
 * @file models/Tag.js
 * @description Mongoose schema & model for Post Tags.
 *
 * TAGS vs CATEGORIES:
 *   - A post belongs to exactly ONE category (the broad topic area).
 *   - A post can have MANY tags (specific keywords for discoverability).
 *   Example: Category = "AI & ML", Tags = ["ChatGPT", "LLM", "Python"]
 *
 * FIELDS:
 *   name      - Display name, e.g. "Machine Learning"
 *   slug      - URL-safe version, e.g. "machine-learning"
 *   postCount - Denormalised counter (same approach as Category.postCount)
 *
 * USAGE:
 *   import Tag from '../models/Tag.js';
 *   const tags = await Tag.find().sort({ postCount: -1 }).limit(20);
 */

import mongoose from 'mongoose';
import { generateSlug } from '../utils/slugHelper.js';

const { Schema, model } = mongoose;

// ── Schema Definition ─────────────────────────────────────────────────────────
const tagSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, 'Tag name is required'],
      trim: true,
      unique: true,
      maxlength: [50, 'Tag name must be 50 characters or less'],
    },

    slug: {
      type: String,
      unique: true,
      lowercase: true,
      trim: true,
    },

    // Denormalised count of published posts using this tag
    postCount: {
      type: Number,
      default: 0,
      min: 0,
    },
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
      transform: (_doc, ret) => {
        ret.id = ret._id;
        delete ret._id;
        delete ret.__v;
        return ret;
      },
    },
    toObject: { virtuals: true },
  }
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MIDDLEWARE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Auto-generate slug from name on creation or name change
tagSchema.pre('save', function (next) {
  if (this.isModified('name') || !this.slug) {
    this.slug = generateSlug(this.name);
  }
  next();
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// STATIC METHODS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Tag.findOrCreate(name)
 * Looks up a tag by name (case-insensitive).
 * Creates it if it doesn't exist. Returns the tag document either way.
 *
 * WHY: The admin post editor lets users type tag names freely.
 * We auto-create missing tags rather than requiring pre-registration.
 *
 * @param {string} name - Tag name as typed by the author
 * @returns {Promise<Document>} - The existing or newly created Tag document
 */
tagSchema.statics.findOrCreate = async function (name) {
  const slug = generateSlug(name);
  // findOneAndUpdate with upsert=true is atomic — no race condition
  return this.findOneAndUpdate(
    { slug },
    { $setOnInsert: { name: name.trim(), slug } },
    { upsert: true, new: true, runValidators: true }
  );
};

/**
 * Tag.incrementPostCount(tagIds)
 * Atomically increments postCount for an array of tag IDs.
 *
 * @param {string[]} tagIds - Array of tag ObjectIds
 */
tagSchema.statics.incrementPostCount = function (tagIds) {
  return this.updateMany({ _id: { $in: tagIds } }, { $inc: { postCount: 1 } });
};

/**
 * Tag.decrementPostCount(tagIds)
 * Atomically decrements postCount for an array of tag IDs.
 *
 * @param {string[]} tagIds - Array of tag ObjectIds
 */
tagSchema.statics.decrementPostCount = function (tagIds) {
  return this.updateMany({ _id: { $in: tagIds } }, { $inc: { postCount: -1 } });
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// INDEXES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Text index on name for autocomplete search in the admin tag picker
tagSchema.index({ name: 'text' });
// Sort tags by popularity (most-used first) for the tag cloud widget
tagSchema.index({ postCount: -1 });

const Tag = model('Tag', tagSchema);
export default Tag;
