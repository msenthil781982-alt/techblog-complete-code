/**
 * @file utils/logger.js
 * @description Lightweight logger wrapper.
 *
 * WHY NOT console.log directly?
 *   - We can suppress output cleanly in test environments.
 *   - We get automatic timestamps and level prefixes.
 *   - In production we could swap this implementation for Winston or Pino
 *     without touching any other file.
 *
 * LEVELS (most → least severe):
 *   error → warn → info → debug
 *
 * USAGE:
 *   import logger from '../utils/logger.js';
 *   logger.info('Server started on port 5000');
 *   logger.error('Something broke', err.message);
 */

import env from '../config/env.js';

/** Formats the current time as HH:MM:SS for log prefixes. */
const timestamp = () =>
  new Date().toTimeString().split(' ')[0]; // "23:14:07"

const logger = {
  /**
   * info — normal operational messages.
   * @param {...any} args
   */
  info: (...args) => {
    console.log(`[${timestamp()}] ℹ️  INFO  `, ...args);
  },

  /**
   * warn — something unexpected but non-fatal.
   * @param {...any} args
   */
  warn: (...args) => {
    console.warn(`[${timestamp()}] ⚠️  WARN  `, ...args);
  },

  /**
   * error — a failure that may affect the user.
   * @param {...any} args
   */
  error: (...args) => {
    console.error(`[${timestamp()}] ❌ ERROR `, ...args);
  },

  /**
   * debug — verbose messages only shown in development.
   * @param {...any} args
   */
  debug: (...args) => {
    if (env.IS_DEV) {
      console.log(`[${timestamp()}] 🐛 DEBUG `, ...args);
    }
  },
};

export default logger;
