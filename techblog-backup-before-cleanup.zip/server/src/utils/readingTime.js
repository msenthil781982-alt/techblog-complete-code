/**
 * @file utils/readingTime.js
 * @description Estimates the reading time for a blog post's content.
 *
 * HOW IT WORKS:
 *   1. Strip all HTML tags from the content string (rich-text editors store
 *      HTML like "<p>Hello <strong>world</strong></p>").
 *   2. Split the remaining plain text on whitespace to count words.
 *   3. Divide by the average adult reading speed (200 wpm) and round up.
 *
 * WHY 200 wpm?
 *   The commonly cited average for online reading is 200–250 wpm.
 *   We use 200 to be slightly generous — readers appreciate the lower number.
 *
 * USAGE:
 *   import calculateReadingTime from '../utils/readingTime.js';
 *
 *   const minutes = calculateReadingTime('<p>Hello world…</p>');
 *   // → 1  (minimum is always 1 min)
 *
 * @param {string} htmlContent - Raw HTML string from the rich-text editor
 * @returns {number}           - Estimated reading time in minutes (min 1)
 */
const calculateReadingTime = (htmlContent = '') => {
  if (!htmlContent) return 1;

  // ── Step 1: Strip HTML tags ───────────────────────────────────────────────
  // Replace every <tag> with a space (not empty string) so words at tag
  // boundaries ("word</p><p>word") aren't concatenated into one long word.
  const plainText = htmlContent
    .replace(/<[^>]+>/g, ' ')   // remove tags
    .replace(/&nbsp;/g, ' ')    // decode common HTML entity
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')       // collapse multiple spaces
    .trim();

  // ── Step 2: Count words ───────────────────────────────────────────────────
  if (!plainText) return 1;
  const wordCount = plainText.split(' ').filter(Boolean).length;

  // ── Step 3: Calculate minutes ─────────────────────────────────────────────
  const WORDS_PER_MINUTE = 200;
  const minutes = Math.ceil(wordCount / WORDS_PER_MINUTE);

  // Always return at least 1 minute
  return Math.max(1, minutes);
};

export default calculateReadingTime;
