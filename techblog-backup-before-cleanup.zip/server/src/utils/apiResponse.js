/**
 * @file utils/apiResponse.js
 * @description Helper functions for sending uniform JSON API responses.
 *
 * WHY this matters:
 *   Every controller should return the same JSON shape regardless of success
 *   or failure. This makes the frontend's job predictable — it always looks
 *   for `data`, `message`, and `success` at the top level.
 *
 * RESPONSE SHAPE:
 *   Success:
 *   {
 *     "success": true,
 *     "message": "Posts fetched successfully",
 *     "data": { ... }          // the actual payload
 *   }
 *
 *   Error (handled by errorHandler.js):
 *   {
 *     "success": false,
 *     "message": "Post not found",
 *     "errors": [ ... ]        // optional validation error details
 *   }
 *
 * USAGE:
 *   import { sendSuccess, sendError } from '../utils/apiResponse.js';
 *
 *   // Inside a controller:
 *   sendSuccess(res, { posts }, 'Posts fetched', 200);
 *   sendError(res, 'Not found', 404);
 */

/**
 * sendSuccess — sends a 2xx JSON response.
 *
 * @param {import('express').Response} res   - Express response object
 * @param {any}    data                      - Payload to include in `data`
 * @param {string} [message='Success']       - Human-readable success message
 * @param {number} [statusCode=200]          - HTTP status code
 */
export const sendSuccess = (res, data = null, message = 'Success', statusCode = 200) => {
  return res.status(statusCode).json({
    success: true,
    message,
    data,
  });
};

/**
 * sendError — sends a 4xx/5xx JSON response.
 *
 * @param {import('express').Response} res   - Express response object
 * @param {string} [message='An error occurred'] - Human-readable error message
 * @param {number} [statusCode=500]          - HTTP status code
 * @param {any[]}  [errors=[]]              - Optional array of validation errors
 */
export const sendError = (res, message = 'An error occurred', statusCode = 500, errors = []) => {
  return res.status(statusCode).json({
    success: false,
    message,
    ...(errors.length > 0 && { errors }), // only include `errors` key if non-empty
  });
};

/**
 * ApiError — a custom Error subclass that carries an HTTP status code.
 *
 * WHY: Express's global error handler can't distinguish a "Post not found"
 * (404) from a programming bug (500) unless we tag errors with a statusCode.
 *
 * USAGE (inside a controller or service):
 *   throw new ApiError('Post not found', 404);
 *
 * The global error handler in middleware/errorHandler.js catches this and
 * calls sendError() with the correct HTTP status automatically.
 */
export class ApiError extends Error {
  /**
   * @param {string} message      - Error message shown to the client
   * @param {number} statusCode   - HTTP status code (e.g. 400, 401, 403, 404)
   * @param {any[]}  [errors=[]] - Optional validation error details
   */
  constructor(message, statusCode = 500, errors = []) {
    super(message);
    this.statusCode = statusCode;
    this.errors = errors;
    this.name = 'ApiError';

    // Maintains proper stack trace in V8 (Node.js / Chrome)
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, ApiError);
    }
  }
}
