/**
 * @file utils/slugHelper.js
 * @description URL-safe slug generation with uniqueness collision handling.
 *
 * WHAT IS A SLUG?
 *   A slug is the URL-friendly version of a string.
 *   "Intro to Machine Learning!" → "intro-to-machine-learning"
 *
 * WHY A HELPER INSTEAD OF USING slugify DIRECTLY?
 *   We need consistent options across the whole project (lowercase, trim, etc.)
 *   and a utility to auto-append a numeric suffix when a slug already exists
 *   in MongoDB (e.g. "my-post", "my-post-2", "my-post-3").
 *
 * USAGE:
 *   import { generateSlug, ensureUniqueSlug } from '../utils/slugHelper.js';
 *
 *   // 1. Plain slug from a string:
 *   generateSlug('Hello World!')  // → "hello-world"
 *
 *   // 2. Unique slug checked against the DB:
 *   const slug = await ensureUniqueSlug('My Post', PostModel);
 *   // If "my-post" exists → returns "my-post-2"
 */

import slugifyLib from 'slugify';

/**
 * generateSlug — converts any string into a URL-safe slug.
 *
 * @param {string} text - Input text (e.g. a blog post title)
 * @returns {string}    - Lowercase, hyphen-separated slug
 */
export const generateSlug = (text = '') => {
  return slugifyLib(text, {
    lower: true,       // "Hello" → "hello"
    strict: true,      // remove characters that are not word chars or hyphens
    trim: true,        // trim leading/trailing whitespace before slugifying
  });
};

/**
 * ensureUniqueSlug — generates a slug and guarantees it doesn't collide
 * with an existing document in the given Mongoose Model.
 *
 * ALGORITHM:
 *   1. Generate the base slug from the title.
 *   2. Query the Model for a document with that exact slug.
 *   3. If none found → return the base slug.
 *   4. If found → append "-2", check again. Increment until unique.
 *
 * @param {string}        title      - The post/category title
 * @param {import('mongoose').Model} Model - Mongoose model to check against
 * @param {string}        [excludeId] - Optional: skip this doc's own slug
 *                                      (used when editing an existing post)
 * @returns {Promise<string>}         - A slug guaranteed to be unique
 */
export const ensureUniqueSlug = async (title, Model, excludeId = null) => {
  const baseSlug = generateSlug(title);
  let slug = baseSlug;
  let counter = 2;

  // Keep checking until we find a slug that isn't taken
  while (true) {
    // Build the query
    const query = { slug };

    // When editing an existing document, exclude it from the collision check
    // so it doesn't collide with its own current slug.
    if (excludeId) {
      query._id = { $ne: excludeId };
    }

    const existing = await Model.findOne(query).select('_id').lean();

    if (!existing) {
      // No collision — this slug is available
      return slug;
    }

    // Collision — try "my-post-2", "my-post-3", etc.
    slug = `${baseSlug}-${counter}`;
    counter++;
  }
};
