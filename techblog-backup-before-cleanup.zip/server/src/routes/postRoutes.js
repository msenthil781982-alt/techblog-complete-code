/**
 * @file routes/postRoutes.js
 * @description Routes for Blog Post discovery and management.
 */

import { Router } from 'express';
import * as postController from '../controllers/postController.js';
import {
  createPostRules,
  updatePostRules,
  listPostsQueryRules,
} from '../validators/postValidators.js';
import validate from '../middleware/validate.js';
import { protect, adminOnly, authorOrAdmin } from '../middleware/auth.js';

const router = Router();

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 1. PUBLIC ROUTES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Public listing with filtering, pagination, search, and sorting
router.get('/', listPostsQueryRules, validate, postController.getPosts);

// Top featured articles
router.get('/featured', postController.getFeaturedPosts);

// Top trending articles by views
router.get('/trending', postController.getTrendingPosts);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 2. USER & ADMIN MANAGEMENT (Declared before /:slug)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Get currently logged-in user's blogs (My Blogs)
router.get('/my-blogs', protect, postController.getMyBlogs);

// List posts in CMS dashboard (Admin only)
router.get('/admin/list', protect, adminOnly, postController.getAdminPosts);

// Admin Accept / Reject blog post
router.patch('/:id/status', protect, adminOnly, postController.updatePostStatus);

// Create new post (Logged-in user: pending approval; Admin: approved/published)
router.post(
  '/',
  protect,
  createPostRules,
  validate,
  postController.createPost
);

// Update existing post
router.put(
  '/:id',
  protect,
  authorOrAdmin,
  updatePostRules,
  validate,
  postController.updatePost
);

// Delete post
router.delete(
  '/:id',
  protect,
  authorOrAdmin,
  postController.deletePost
);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 3. SINGLE POST DETAILS (Declared last to avoid capturing literal paths)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Public post detail by slug (increments view count, fetches related & navigation)
router.get('/:slug', postController.getPostBySlug);

export default router;
