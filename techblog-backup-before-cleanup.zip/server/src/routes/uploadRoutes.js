/**
 * @file routes/uploadRoutes.js
 * @description Upload routes for images and rich media assets.
 */

import { Router } from 'express';
import * as uploadController from '../controllers/uploadController.js';
import { upload, handleUploadError } from '../middleware/upload.js';
import { protect, authorOrAdmin } from '../middleware/auth.js';

const router = Router();

// Single image upload (field name: 'image')
router.post(
  '/image',
  protect,
  authorOrAdmin,
  handleUploadError(upload.single('image')),
  uploadController.uploadImage
);

// Multiple image upload (field name: 'images', max 5)
router.post(
  '/images',
  protect,
  authorOrAdmin,
  handleUploadError(upload.array('images', 5)),
  uploadController.uploadMultipleImages
);

// Delete image asset
router.delete(
  '/image',
  protect,
  authorOrAdmin,
  uploadController.deleteImage
);

export default router;
