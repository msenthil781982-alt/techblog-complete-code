/**
 * @file routes/authRoutes.js
 * @description Mounts all authentication API endpoints.
 *
 * ROUTE MAP:
 *   POST /api/auth/login    → login (public)
 *   POST /api/auth/refresh  → refreshToken (public — uses httpOnly cookie)
 *   POST /api/auth/logout   → logout (protected — needs valid access token)
 *   GET  /api/auth/me       → getMe (protected — returns current user)
 *
 * EXTRA SECURITY — login rate limiter:
 *   The /login endpoint gets its OWN, stricter rate limiter (5 req / 15 min)
 *   on top of the global one (100 req / 15 min from app.js).
 *   This makes brute-force attacks on admin credentials impractical.
 */

import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import * as authController from '../controllers/authController.js';
import { loginRules, registerRules, refreshRules } from '../validators/authValidators.js';
import validate from '../middleware/validate.js';
import { protect } from '../middleware/auth.js';

const router = Router();

// ── Login-specific rate limiter ───────────────────────────────────────────────
// 5 failed attempts per 15 minutes per IP address.
// This is separate from (and stricter than) the global limiter in app.js.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 5,
  message: {
    success: false,
    message: 'Too many login attempts. Please try again after 15 minutes.',
  },
  standardHeaders: true,
  legacyHeaders: false,
  // Count failed requests only (don't penalise successful logins)
  skipSuccessfulRequests: true,
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ROUTES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * POST /api/auth/register
 * Public endpoint. Allows users to register.
 */
router.post('/register', registerRules, validate, authController.register);

/**
 * POST /api/auth/login
 * Public endpoint. Validates body, then calls the login controller.
 * Pipeline: loginLimiter → loginRules (validation) → validate → controller
 */
router.post('/login', loginLimiter, loginRules, validate, authController.login);

/**
 * POST /api/auth/refresh
 * Public endpoint. Reads refresh token from httpOnly cookie or request body.
 * Pipeline: refreshRules (body fallback validation) → validate → controller
 */
router.post('/refresh', refreshRules, validate, authController.refreshToken);

/**
 * POST /api/auth/logout
 * Protected — requires a valid access token.
 * Clears the httpOnly refresh cookie and instructs client to discard access token.
 */
router.post('/logout', protect, authController.logout);

/**
 * GET /api/auth/me
 * Protected — returns the current user's profile.
 * Used by the React app on startup to restore session without re-login.
 */
router.get('/me', protect, authController.getMe);

export default router;
