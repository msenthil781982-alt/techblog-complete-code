/**
 * @file routes/newsletterRoutes.js
 * @description Newsletter subscription routes.
 */

import { Router } from 'express';
import { body } from 'express-validator';
import rateLimit from 'express-rate-limit';
import * as newsletterController from '../controllers/newsletterController.js';
import validate from '../middleware/validate.js';
import { protect, adminOnly } from '../middleware/auth.js';

const router = Router();

// Dedicated rate limiter for subscription endpoint to prevent spamming
const subscribeLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // max 10 subscription attempts per 15 min per IP
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: 'Too many subscription attempts. Please try again after 15 minutes.',
  },
});

const subscribeRules = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required')
    .isEmail().withMessage('Invalid email.'),
];

/**
 * POST /api/newsletter/subscribe
 * Public endpoint to subscribe to newsletter.
 */
router.post('/subscribe', subscribeLimiter, subscribeRules, validate, newsletterController.subscribe);

/**
 * POST /api/newsletter/unsubscribe
 * Public endpoint to unsubscribe.
 */
router.post('/unsubscribe', newsletterController.unsubscribe);

/**
 * GET /api/newsletter/subscribers
 * Protected endpoint for admins to view subscribers list.
 */
router.get('/subscribers', protect, adminOnly, newsletterController.getSubscribers);

export default router;
