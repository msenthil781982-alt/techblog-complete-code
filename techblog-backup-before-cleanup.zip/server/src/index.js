/**
 * @file index.js
 * @description HTTP server entry point.
 *
 * RESPONSIBILITY:
 *   1. Loads environment variables (via importing env.js first)
 *   2. Connects to MongoDB
 *   3. Creates the HTTP server from the Express app
 *   4. Starts listening on the configured PORT
 *   5. Sets up graceful shutdown on SIGTERM / SIGINT
 *
 * WHY separate app.js and index.js?
 *   app.js exports the Express application (pure logic, no side effects).
 *   index.js is the "runner" — it connects to real services and starts the
 *   server.  In tests you can import app.js directly without connecting to
 *   MongoDB or occupying a port.
 *
 * START COMMAND:
 *   node src/index.js          (production)
 *   nodemon src/index.js       (development — via `npm run dev`)
 */

// ── Load & validate environment variables first ───────────────────────────────
// This import runs validateEnv() immediately. If any required variable is
// missing the process exits with a clear error before anything else runs.
import env from './config/env.js';

import http from 'http';
import app from './app.js';
import connectDB from './config/db.js';
import logger from './utils/logger.js';
import initScheduler from './services/scheduler.js';

// ── Connect to MongoDB ────────────────────────────────────────────────────────
// connectDB() is async. We await it before starting the HTTP server so the
// app never receives requests while the DB connection is still pending.
await connectDB();

// ── Background Publication Scheduler ──────────────────────────────────────────
initScheduler();

// ── Create the HTTP server ────────────────────────────────────────────────────
// We wrap Express in Node's http.Server rather than using app.listen()
// directly. This gives us a reference to the server for graceful shutdown.
const server = http.createServer(app);

// ── Start listening ───────────────────────────────────────────────────────────
server.listen(env.PORT, () => {
  logger.info(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  logger.info(`🚀  TechBlog API Server started`);
  logger.info(`    Mode        : ${env.NODE_ENV}`);
  logger.info(`    Port        : ${env.PORT}`);
  logger.info(`    Health URL  : http://localhost:${env.PORT}/api/health`);
  logger.info(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// GRACEFUL SHUTDOWN
// When a container / process manager sends SIGTERM (e.g. Docker stop, Heroku
// restart), or when you press Ctrl+C (SIGINT), we:
//   1. Stop accepting new HTTP connections.
//   2. Close the MongoDB connection cleanly.
//   3. Exit with code 0 (success).
//
// This prevents requests from being cut off mid-flight in production.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * shutdown — stop the server and DB connection gracefully.
 * @param {string} signal - The OS signal received (SIGTERM | SIGINT)
 */
const shutdown = (signal) => {
  logger.warn(`${signal} received — shutting down gracefully…`);

  // server.close() stops new connections; the callback fires once all
  // existing connections have finished.
  server.close(async () => {
    logger.info('HTTP server closed.');

    // Import mongoose lazily to avoid circular dependency issues
    const { default: mongoose } = await import('mongoose');
    await mongoose.connection.close();
    logger.info('MongoDB connection closed.');

    logger.info('Goodbye! 👋');
    process.exit(0);
  });

  // Force exit if shutdown takes more than 10 seconds (stuck connections)
  setTimeout(() => {
    logger.error('Graceful shutdown timed out — forcing exit.');
    process.exit(1);
  }, 10_000);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// UNHANDLED REJECTIONS / EXCEPTIONS
// Safety net — catches any Promise rejection or thrown error that wasn't
// handled anywhere in the codebase and would otherwise silently swallow.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Promise Rejection:', reason);
  shutdown('unhandledRejection');
});

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err.message);
  shutdown('uncaughtException');
});
