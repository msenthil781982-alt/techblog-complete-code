/**
 * @file controllers/authController.js
 * @description Handles all authentication logic: login, token refresh,
 *              logout, and fetching the currently-logged-in user (getMe).
 *
 * ════════════════════════════════════════════════════════════════════════════
 * TOKEN STRATEGY (Dual-Token Pattern):
 *
 *   ACCESS TOKEN  (short-lived: 7d by default)
 *     ► Sent in every API request as `Authorization: Bearer <token>`
 *     ► Stored in localStorage on the client (simple; acceptable for a CMS)
 *     ► Verified by the `auth` middleware on every protected route
 *
 *   REFRESH TOKEN (long-lived: 30d)
 *     ► Used ONLY to get a new access token when it expires
 *     ► Stored in an httpOnly, Secure cookie on the client
 *     ► httpOnly = JavaScript can't read it (XSS-safe)
 *     ► The client sends it automatically to POST /api/auth/refresh
 *
 * WHY TWO TOKENS?
 *   A short-lived access token limits the damage if it's intercepted —
 *   it expires quickly. The refresh token (in a cookie JS can't touch)
 *   lets the user stay logged in without re-entering their password.
 * ════════════════════════════════════════════════════════════════════════════
 *
 * ENDPOINTS HANDLED:
 *   POST /api/auth/login    → login()
 *   POST /api/auth/refresh  → refreshToken()
 *   POST /api/auth/logout   → logout()
 *   GET  /api/auth/me       → getMe()
 */

import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import env from '../config/env.js';
import { sendSuccess, sendError, ApiError } from '../utils/apiResponse.js';
import logger from '../utils/logger.js';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// TOKEN HELPERS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * signAccessToken — creates a short-lived JWT access token.
 *
 * PAYLOAD contains only the minimum needed:
 *   id   → to look up the user on protected routes
 *   role → to perform role checks without an extra DB query
 *
 * @param {Document} user - Mongoose User document
 * @returns {string} Signed JWT string
 */
const signAccessToken = (user) =>
  jwt.sign(
    { id: user._id.toString(), role: user.role },
    env.JWT_SECRET,
    { expiresIn: env.JWT_EXPIRES_IN }  // e.g. "7d"
  );

/**
 * signRefreshToken — creates a long-lived JWT refresh token.
 * Contains only the user ID — no sensitive data.
 *
 * @param {Document} user - Mongoose User document
 * @returns {string} Signed JWT string
 */
const signRefreshToken = (user) =>
  jwt.sign(
    { id: user._id.toString() },
    env.JWT_REFRESH_SECRET,
    { expiresIn: env.JWT_REFRESH_EXPIRES_IN } // e.g. "30d"
  );

/**
 * setRefreshTokenCookie — attaches the refresh token as an httpOnly cookie.
 *
 * Cookie options:
 *   httpOnly : JS cannot read it (protects against XSS)
 *   secure   : only sent over HTTPS (enabled in production)
 *   sameSite : "strict" prevents CSRF attacks
 *   maxAge   : matches JWT_REFRESH_EXPIRES_IN (30 days in ms)
 *
 * @param {import('express').Response} res
 * @param {string} token - The refresh token string
 */
const setRefreshTokenCookie = (res, token) => {
  const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;

  res.cookie('refreshToken', token, {
    httpOnly: true,
    secure: env.IS_PROD,         // HTTPS only in production
    sameSite: 'strict',
    maxAge: thirtyDaysMs,
    path: '/api/auth/refresh',   // Cookie only sent to the refresh endpoint
  });
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CONTROLLERS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * register — POST /api/auth/register
 * Allows new users to create an account and immediately log in.
 */
export const register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      throw new ApiError('Email is already registered. Please log in.', 400);
    }

    const user = new User({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password,
      role: 'user',
    });

    await user.save();

    const accessToken = signAccessToken(user);
    const refreshToken = signRefreshToken(user);
    setRefreshTokenCookie(res, refreshToken);

    logger.info(`User registered: ${user.email}`);

    return sendSuccess(
      res,
      {
        accessToken,
        user: user.toJSON(),
      },
      'Registration successful',
      201
    );
  } catch (err) {
    next(err);
  }
};

/**
 * login — POST /api/auth/login
 *
 * FLOW:
 *   1. Find user by email (include password field — excluded by default)
 *   2. Check user is active
 *   3. Compare submitted password against bcrypt hash
 *   4. Update lastLoginAt
 *   5. Issue access + refresh tokens
 *   6. Return access token in JSON body, refresh token in httpOnly cookie
 *
 * WHY include the access token in the JSON body (not a cookie)?
 *   The admin SPA needs to attach it to every API request via an Axios
 *   interceptor. Storing it in memory or localStorage is simplest for
 *   a CMS with a single admin user and no public-facing sensitive data.
 */
export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // ── 1. Find user — explicitly select password (select: false by default) ──
    const user = await User.findOne({ email: email.toLowerCase() }).select('+password');

    if (!user) {
      // Use a generic message — don't reveal whether the email exists
      throw new ApiError('Invalid email or password', 401);
    }

    // ── 2. Check account is active ────────────────────────────────────────────
    if (!user.isActive) {
      throw new ApiError('Your account has been deactivated. Contact support.', 403);
    }

    // ── 3. Verify password ────────────────────────────────────────────────────
    const isPasswordCorrect = await user.comparePassword(password);
    if (!isPasswordCorrect) {
      throw new ApiError('Invalid email or password', 401);
    }

    // ── 4. Update lastLoginAt ──────────────────────────────────────────────────
    // Use $set directly to avoid triggering the full pre-save hook
    await User.findByIdAndUpdate(user._id, { lastLoginAt: new Date() });

    // ── 5. Issue tokens ───────────────────────────────────────────────────────
    const accessToken  = signAccessToken(user);
    const refreshToken = signRefreshToken(user);

    // ── 6. Send response ──────────────────────────────────────────────────────
    setRefreshTokenCookie(res, refreshToken);

    logger.info(`Admin login: ${user.email} (${user.role})`);

    return sendSuccess(
      res,
      {
        accessToken,
        user: user.toJSON(), // toJSON() strips password, __v, renames _id → id
      },
      'Login successful',
      200
    );
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────────────────────────────────────

/**
 * refreshToken — POST /api/auth/refresh
 *
 * FLOW:
 *   1. Read the refresh token from the httpOnly cookie OR request body
 *      (body fallback for clients that can't use cookies, e.g. Postman)
 *   2. Verify the refresh token with JWT_REFRESH_SECRET
 *   3. Find the user to confirm they still exist and are active
 *   4. Issue a new access token (and optionally rotate the refresh token)
 */
export const refreshToken = async (req, res, next) => {
  try {
    // Read from httpOnly cookie first; fall back to request body
    const token = req.cookies?.refreshToken || req.body?.refreshToken;

    if (!token) {
      throw new ApiError('Refresh token not provided', 401);
    }

    // ── Verify refresh token ──────────────────────────────────────────────────
    let decoded;
    try {
      decoded = jwt.verify(token, env.JWT_REFRESH_SECRET);
    } catch {
      throw new ApiError('Invalid or expired refresh token. Please log in again.', 401);
    }

    // ── Confirm user still exists and is active ───────────────────────────────
    const user = await User.findById(decoded.id);
    if (!user || !user.isActive) {
      throw new ApiError('User no longer exists or has been deactivated.', 401);
    }

    // ── Issue fresh access token ──────────────────────────────────────────────
    const newAccessToken = signAccessToken(user);

    // Rotate the refresh token (issue a new one, extending the session)
    const newRefreshToken = signRefreshToken(user);
    setRefreshTokenCookie(res, newRefreshToken);

    return sendSuccess(
      res,
      { accessToken: newAccessToken },
      'Token refreshed successfully',
      200
    );
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────────────────────────────────────

/**
 * logout — POST /api/auth/logout
 *
 * FLOW:
 *   1. Clear the httpOnly refresh token cookie
 *   2. The client is responsible for discarding the access token
 *      (remove from localStorage / in-memory state)
 *
 * NOTE: We cannot actively invalidate a JWT (they're stateless by design).
 * For a blog CMS this is acceptable. If you need true token revocation,
 * add a Redis-based token blacklist in production.
 */
export const logout = async (req, res, next) => {
  try {
    // Clear the httpOnly cookie by setting maxAge to 0
    res.cookie('refreshToken', '', {
      httpOnly: true,
      secure: env.IS_PROD,
      sameSite: 'strict',
      maxAge: 0,                       // expire immediately
      path: '/api/auth/refresh',
    });

    logger.info(`Logout: user ${req.user?.id}`);

    return sendSuccess(res, null, 'Logged out successfully', 200);
  } catch (err) {
    next(err);
  }
};

// ─────────────────────────────────────────────────────────────────────────────

/**
 * getMe — GET /api/auth/me
 *
 * Returns the currently logged-in admin's profile.
 * Protected by the `auth` middleware — `req.user` is already populated.
 *
 * Used by the React app on startup to restore session state without
 * requiring a re-login if the access token in localStorage is still valid.
 */
export const getMe = async (req, res, next) => {
  try {
    // req.user.id was set by the auth middleware
    const user = await User.findById(req.user.id);

    if (!user) {
      throw new ApiError('User not found', 404);
    }

    return sendSuccess(res, { user: user.toJSON() }, 'User fetched successfully', 200);
  } catch (err) {
    next(err);
  }
};
