/**
 * @file middleware/validate.js
 * @description express-validator result checker middleware.
 *
 * HOW IT WORKS:
 *   Routes define validation RULES using express-validator chains, e.g.:
 *     body('email').isEmail().normalizeEmail()
 *
 *   Those chains don't reject the request by themselves — they just collect
 *   errors into the request object.  This middleware runs AFTER the chains
 *   and BEFORE the controller; it checks if any errors were collected and
 *   responds with 400 if so, preventing invalid data from reaching the DB.
 *
 * USAGE (inside a route file):
 *   import { body } from 'express-validator';
 *   import validate from '../middleware/validate.js';
 *
 *   router.post(
 *     '/login',
 *     [
 *       body('email').isEmail().withMessage('Valid email required'),
 *       body('password').isLength({ min: 6 }).withMessage('Min 6 characters'),
 *     ],
 *     validate,         // ← placed here, between rules and controller
 *     authController.login
 *   );
 */

import { validationResult } from 'express-validator';
import { sendError } from '../utils/apiResponse.js';

/**
 * validate — reads express-validator results and short-circuits on failure.
 *
 * @param {import('express').Request}      req
 * @param {import('express').Response}     res
 * @param {import('express').NextFunction}  next
 */
const validate = (req, res, next) => {
  // validationResult() reads the error array that the validation chains
  // attached to `req` during this request's middleware pipeline.
  const result = validationResult(req);

  if (!result.isEmpty()) {
    // Map express-validator errors to a consistent shape:
    // [ { field: 'email', message: 'Valid email required' }, ... ]
    const errors = result.array().map((err) => ({
      field: err.path,       // the field name (e.g. 'email')
      message: err.msg,      // our custom message string
    }));

    return sendError(res, 'Validation failed', 400, errors);
  }

  // No validation errors — proceed to the controller
  next();
};

export default validate;
