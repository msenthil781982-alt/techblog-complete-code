/**
 * @file middleware/errorHandler.js
 * @description Global Express error-handling middleware.
 *
 * HOW IT WORKS:
 *   Express recognises a middleware function with FOUR parameters
 *   (err, req, res, next) as an error handler.
 *   It MUST be registered LAST in app.js — after all routes.
 *
 * WHAT IT HANDLES:
 *   1. Our own ApiError instances          → use their statusCode + message
 *   2. Mongoose CastError (bad ObjectId)   → 400 "Invalid ID"
 *   3. Mongoose ValidationError            → 400 with field details
 *   4. Mongoose duplicate key (code 11000) → 409 "already exists"
 *   5. JWT errors                          → 401
 *   6. Everything else                     → 500 Internal Server Error
 *
 * USAGE:
 *   // In any controller or middleware:
 *   throw new ApiError('Post not found', 404);
 *   // or:
 *   next(new ApiError('Unauthorized', 401));
 *
 * The error bubbles up and lands here automatically.
 */

import { sendError, ApiError } from '../utils/apiResponse.js';
import logger from '../utils/logger.js';
import env from '../config/env.js';

/**
 * errorHandler — the single global error handler for the entire API.
 *
 * @param {Error}                      err
 * @param {import('express').Request}  req
 * @param {import('express').Response} res
 * @param {import('express').NextFunction} next  - must be declared even if unused
 */
// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  // Always log the full error server-side for debugging
  logger.error(`${req.method} ${req.originalUrl} → ${err.message}`);

  // In development, also log the stack trace
  if (env.IS_DEV) {
    logger.debug(err.stack);
  }

  // ── 1. Our custom ApiError ───────────────────────────────────────────────
  if (err instanceof ApiError) {
    return sendError(res, err.message, err.statusCode, err.errors);
  }

  // ── 2. Mongoose CastError (e.g. invalid ObjectId: "abc" instead of hex) ──
  //       Happens when a route like GET /posts/:id receives a malformed id.
  if (err.name === 'CastError') {
    return sendError(res, `Invalid value for field: ${err.path}`, 400);
  }

  // ── 3. Mongoose ValidationError (schema-level validation failed) ──────────
  if (err.name === 'ValidationError') {
    // Collect all field error messages into an array
    const errors = Object.values(err.errors).map((e) => ({
      field: e.path,
      message: e.message,
    }));
    return sendError(res, 'Validation failed', 400, errors);
  }

  // ── 4. MongoDB duplicate key error (unique index violation) ───────────────
  //       e.g. trying to create a category with an existing slug
  if (err.code === 11000) {
    // Extract the field name from the error keyValue object
    const field = Object.keys(err.keyValue || {})[0] || 'field';
    const value = err.keyValue?.[field];
    return sendError(
      res,
      `A record with ${field} "${value}" already exists.`,
      409 // 409 Conflict
    );
  }

  // ── 5. JWT errors ──────────────────────────────────────────────────────────
  if (err.name === 'JsonWebTokenError') {
    return sendError(res, 'Invalid token. Please log in again.', 401);
  }

  if (err.name === 'TokenExpiredError') {
    return sendError(res, 'Token expired. Please log in again.', 401);
  }

  // ── 6. Fallback: unexpected / programming error ───────────────────────────
  //       Never leak internal error details to the client in production.
  const message = env.IS_DEV
    ? err.message               // show real message in development
    : 'Internal server error';  // generic message in production

  return sendError(res, message, 500);
};

export default errorHandler;
