/**
 * @file middleware/auth.js
 * @description JWT verification middleware — protects admin routes.
 *
 * HOW IT WORKS:
 *   1. Reads the Authorization header: "Bearer <token>"
 *   2. Verifies the token with JWT_SECRET
 *   3. Looks up the user in the DB (confirms they still exist and are active)
 *   4. Attaches the user object to `req.user` for downstream controllers
 *   5. Calls `next()` — the protected route handler runs
 *
 * USAGE (in a route file):
 *   import { protect, adminOnly } from '../middleware/auth.js';
 *
 *   // Any logged-in user (admin OR author):
 *   router.get('/my-posts', protect, postController.getMyPosts);
 *
 *   // Admin only:
 *   router.delete('/posts/:id', protect, adminOnly, postController.deletePost);
 *
 * req.user SHAPE (after protect middleware):
 *   {
 *     id:    '64a1...',   // MongoDB ObjectId string
 *     role:  'admin',     // 'admin' | 'author'
 *     email: '...',
 *     name:  '...',
 *     ...                 // full User document (without password)
 *   }
 */

import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import env from '../config/env.js';
import { ApiError } from '../utils/apiResponse.js';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// protect — verify JWT and attach user to req
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * protect — JWT authentication guard.
 * Must be placed before any route handler that requires a logged-in user.
 *
 * @param {import('express').Request}      req
 * @param {import('express').Response}     res
 * @param {import('express').NextFunction}  next
 */
export const protect = async (req, res, next) => {
  try {
    // ── 1. Extract token from Authorization header ────────────────────────────
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new ApiError('No authentication token provided. Please log in.', 401);
    }

    // "Bearer eyJhbGciOiJIUzI1NiIsInR..." → "eyJhbGciOiJIUzI1NiIsInR..."
    const token = authHeader.split(' ')[1];

    if (!token) {
      throw new ApiError('Malformed authorization header.', 401);
    }

    // ── 2. Verify the token ───────────────────────────────────────────────────
    // jwt.verify() throws JsonWebTokenError if invalid, TokenExpiredError if expired.
    // Both are caught by the global errorHandler and mapped to 401 responses.
    const decoded = jwt.verify(token, env.JWT_SECRET);
    // decoded = { id: '64a1...', role: 'admin', iat: ..., exp: ... }

    // ── 3. Confirm the user still exists and is active ────────────────────────
    // WHY re-query the DB?
    //   The JWT is stateless — it doesn't know if the user was deactivated
    //   after the token was issued. This check prevents deactivated admins
    //   from using an old, still-valid token.
    const user = await User.findById(decoded.id).select('-password');

    if (!user) {
      throw new ApiError('The user belonging to this token no longer exists.', 401);
    }

    if (!user.isActive) {
      throw new ApiError('Your account has been deactivated.', 403);
    }

    // ── 4. Attach user to request object ──────────────────────────────────────
    // All downstream route handlers can access req.user
    req.user = user;

    next();
  } catch (err) {
    // Pass JWT errors (JsonWebTokenError, TokenExpiredError) and ApiErrors
    // to the global error handler, which maps them to 401 responses.
    next(err);
  }
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// adminOnly — role guard (must be used AFTER protect)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * adminOnly — role guard that allows only users with role === 'admin'.
 * MUST be chained AFTER `protect` (which populates req.user).
 *
 * Usage: router.delete('/users/:id', protect, adminOnly, controller.deleteUser);
 */
export const adminOnly = (req, res, next) => {
  if (req.user?.role !== 'admin') {
    return next(new ApiError('Access denied. Admin privileges required.', 403));
  }
  next();
};

/**
 * authorOrAdmin — allows both authors and admins.
 * Used for routes where an author can manage their OWN content.
 *
 * Usage: router.put('/posts/:id', protect, authorOrAdmin, controller.updatePost);
 * (The controller then checks ownership if the user is an author.)
 */
export const authorOrAdmin = (req, res, next) => {
  if (!['admin', 'author'].includes(req.user?.role)) {
    return next(new ApiError('Access denied.', 403));
  }
  next();
};
