/**
 * @file services/authService.js
 * @description Authentication API methods for login, logout, profile fetch, and refresh.
 */

import api from './api';

export const authService = {
  /**
   * User registration
   * @param {Object} userData - { name, email, password }
   * @returns {Promise<{ accessToken: string, user: Object }>}
   */
  async register(userData) {
    const res = await api.post('/auth/register', userData);
    return res.data?.data;
  },

  /**
   * Admin / Author / User login
   * @param {Object} credentials - { email, password }
   * @returns {Promise<{ accessToken: string, user: Object }>}
   */
  async login(credentials) {
    const res = await api.post('/auth/login', credentials);
    return res.data?.data;
  },

  /**
   * Fetch currently authenticated user profile
   * @returns {Promise<{ user: Object }>}
   */
  async getMe() {
    const res = await api.get('/auth/me');
    return res.data?.data;
  },

  /**
   * Request a new access token via refresh token
   * @returns {Promise<{ accessToken: string }>}
   */
  async refreshToken() {
    const res = await api.post('/auth/refresh');
    return res.data?.data;
  },

  /**
   * Log out user and clear refresh token cookie
   * @returns {Promise<void>}
   */
  async logout() {
    try {
      await api.post('/auth/logout');
    } finally {
      localStorage.removeItem('techblog_access_token');
      localStorage.removeItem('techblog_user');
    }
  },
};

export default authService;
