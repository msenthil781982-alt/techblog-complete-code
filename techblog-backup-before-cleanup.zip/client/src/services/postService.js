/**
 * @file services/postService.js
 * @description Centralized API client methods for Posts and Categories.
 */

import api from './api';

export const postService = {
  /**
   * Fetch paginated list of public posts
   * @param {Object} params - { page, limit, category, tag, search, featured, sort }
   */
  async getPosts(params = {}) {
    const res = await api.get('/posts', { params });
    return res.data?.data;
  },

  /**
   * Fetch single article by URL slug
   * @param {string} slug
   */
  async getPostBySlug(slug) {
    const res = await api.get(`/posts/${slug}`);
    return res.data?.data;
  },

  /**
   * Fetch top featured articles for hero banner
   */
  async getFeaturedPosts() {
    const res = await api.get('/posts/featured');
    return res.data?.data?.posts || [];
  },

  /**
   * Fetch popular articles ranked by views
   */
  async getTrendingPosts() {
    const res = await api.get('/posts/trending');
    return res.data?.data?.posts || [];
  },

  /**
   * Fetch active category list
   */
  async getCategories() {
    const res = await api.get('/categories');
    return res.data?.data?.categories || [];
  },

  /**
   * Fetch single category details by slug
   * @param {string} slug
   */
  async getCategoryBySlug(slug) {
    const res = await api.get(`/categories/${slug}`);
    return res.data?.data?.category;
  },

  /**
   * Fetch admin/author posts list for CMS Dashboard
   * @param {Object} params - { page, limit, status, search, category }
   */
  async getAdminPosts(params = {}) {
    const res = await api.get('/posts/admin/list', { params });
    return res.data?.data;
  },

  /**
   * Fetch currently logged-in user's submitted blogs
   */
  async getMyBlogs() {
    const res = await api.get('/posts/my-blogs');
    return res.data?.data?.posts || [];
  },

  /**
   * Admin Accept / Reject a blog post
   * @param {string} id
   * @param {'approved'|'rejected'} status
   */
  async updatePostStatus(id, status) {
    const res = await api.patch(`/posts/${id}/status`, { status });
    return res.data?.data?.post;
  },

  /**
   * Create a new post
   * @param {Object} postData
   */
  async createPost(postData) {
    const res = await api.post('/posts', postData);
    return res.data?.data?.post;
  },

  /**
   * Update an existing post
   * @param {string} id
   * @param {Object} postData
   */
  async updatePost(id, postData) {
    const res = await api.put(`/posts/${id}`, postData);
    return res.data?.data?.post;
  },

  /**
   * Delete a post
   * @param {string} id
   */
  async deletePost(id) {
    const res = await api.delete(`/posts/${id}`);
    return res.data;
  },

  /**
   * Upload an image file
   * @param {FormData} formData
   */
  async uploadImage(formData) {
    const res = await api.post('/upload/image', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return res.data?.data;
  },
};

export default postService;
