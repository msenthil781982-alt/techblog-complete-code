/**
 * @file services/api.js
 * @description Centralized Axios instance with request and response interceptors.
 *
 * FEATURES:
 *   1. Automatic JWT Bearer token attachment on all outbound requests
 *   2. withCredentials: true (allows sending/receiving httpOnly refresh cookies)
 *   3. Transparent response error handling (extracts API error message)
 *   4. Automatic session cleanup on 401 Unauthorized responses
 */

import axios from 'axios';

// Create base instance
const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  withCredentials: true, // Send httpOnly cookies with requests
  headers: {
    'Content-Type': 'application/json',
  },
});

// ── Request Interceptor ───────────────────────────────────────────────────────
api.interceptors.request.use(
  (config) => {
    // Read access token from localStorage
    const token = localStorage.getItem('techblog_access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response Interceptor ──────────────────────────────────────────────────────
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // Normalize error message from backend's uniform response format
    const serverMessage =
      error.response?.data?.message ||
      error.response?.data?.errors?.[0]?.message ||
      error.message ||
      'An unexpected error occurred';

    // If 401 Unauthorized occurs on an authenticated route and not already retried
    if (error.response?.status === 401 && !originalRequest._retry) {
      // Avoid infinite refresh loops if refresh itself fails or request was to login
      if (
        originalRequest.url.includes('/auth/login') ||
        originalRequest.url.includes('/auth/refresh')
      ) {
        return Promise.reject(new Error(serverMessage));
      }

      originalRequest._retry = true;

      try {
        // Attempt to obtain a new access token using the httpOnly refresh cookie
        const res = await axios.post(
          `${import.meta.env.VITE_API_BASE_URL || '/api'}/auth/refresh`,
          {},
          { withCredentials: true }
        );

        const newAccessToken = res.data?.data?.accessToken;
        if (newAccessToken) {
          localStorage.setItem('techblog_access_token', newAccessToken);
          api.defaults.headers.common.Authorization = `Bearer ${newAccessToken}`;
          originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
          return api(originalRequest);
        }
      } catch (refreshErr) {
        // Refresh token failed or expired: clear local token
        localStorage.removeItem('techblog_access_token');
        localStorage.removeItem('techblog_user');
        // If we are currently in an admin route, redirect to login
        if (window.location.pathname.startsWith('/admin') && window.location.pathname !== '/admin/login') {
          window.location.href = '/admin/login';
        }
        return Promise.reject(new Error('Session expired. Please log in again.'));
      }
    }

    return Promise.reject(new Error(serverMessage));
  }
);

export default api;
