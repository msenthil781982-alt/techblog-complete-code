/**
 * @file services/newsletterService.js
 * @description Frontend API service for newsletter subscriptions.
 */

import api from './api';

/**
 * Subscribes an email to the newsletter.
 * @param {string} email
 * @returns {Promise<any>}
 */
export const subscribeNewsletter = async (email) => {
  const response = await api.post('/newsletter/subscribe', { email });
  return response.data;
};

/**
 * Unsubscribes an email from the newsletter.
 * @param {string} email
 * @returns {Promise<any>}
 */
export const unsubscribeNewsletter = async (email) => {
  const response = await api.post('/newsletter/unsubscribe', { email });
  return response.data;
};

export default {
  subscribeNewsletter,
  unsubscribeNewsletter,
};

