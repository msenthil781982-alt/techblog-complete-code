/**
 * @file components/admin/ProtectedRoute.jsx
 * @description Higher-Order component that restricts routes to authenticated admins/authors.
 */

import React from 'react';
import { Navigate, useLocation, Outlet } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const ProtectedRoute = ({ roleRequired = null }) => {
  const { isAuthenticated, isLoading, user } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-[#2563eb] border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-medium text-gray-500">Authenticating session...</p>
        </div>
      </div>
    );
  }

  // Not logged in -> send to login page preserving the current URL
  if (!isAuthenticated) {
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  // Role requirement check (if specified)
  if (roleRequired && user?.role !== roleRequired) {
    return <Navigate to="/" replace />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
