/**
 * @file hooks/usePosts.js
 * @description React Query hooks for fetching posts feeds, featured, and trending articles.
 */

import { useQuery } from '@tanstack/react-query';
import postService from '../services/postService';

/**
 * Hook to fetch paginated & filtered posts
 * @param {Object} params - { page, limit, category, tag, search, featured, sort }
 */
export const usePosts = (params = {}) => {
  return useQuery({
    queryKey: ['posts', params],
    queryFn: () => postService.getPosts(params),
    keepPreviousData: true,
  });
};

/**
 * Hook to fetch top featured posts for the hero spotlight
 */
export const useFeaturedPosts = () => {
  return useQuery({
    queryKey: ['posts', 'featured'],
    queryFn: () => postService.getFeaturedPosts(),
  });
};

/**
 * Hook to fetch top trending posts for the sidebar
 */
export const useTrendingPosts = () => {
  return useQuery({
    queryKey: ['posts', 'trending'],
    queryFn: () => postService.getTrendingPosts(),
  });
};

/**
 * Hook to fetch a single article by slug
 * @param {string} slug
 */
export const usePost = (slug) => {
  return useQuery({
    queryKey: ['post', slug],
    queryFn: () => postService.getPostBySlug(slug),
    enabled: Boolean(slug),
  });
};
